load data;

ratings = batchEPTrueSkill(G,W,100); 
[sorted_ratings ind] = sort(ratings,'descend');

fprintf('\n\n');
for i=1:5
	fprintf('%d %3.2f %s\n', i, ratings(ind(i)), W{ind(i)});
end

err = norm(ratings-soln_ratings);
if (err > 1e-5)
	fprintf('FAILED.\n')
else
	fprintf('PASSED!\n');
end

%% INSERT CODE HERE %%
%% Generate plots as in assignment %%

