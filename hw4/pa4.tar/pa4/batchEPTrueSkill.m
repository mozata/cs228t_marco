function ratings = batchEPTrueSkill(G,W,blockSize)
%% Performs a single sweep of EP over the games data in blocks,
%% performing multiple iterations of message passing per block of data
%% to approximately calculate the mean and the variance of each 
%% player's skill.

%% NOTE : All messages passed are in the form of Gaussian precisions and potentials.
%%		Even if a node is non Gaussian internally, it will both receive and send
%%		its messages in this format.

%% Refer the handout for details of the model

%% Inputs:
%%		G (M x 2) : G(i,1) is the winner of the i-th game, 
%%						and G(i,2) is the loser of the i-th game
%%		W (N x 1) : cell-array with W{i} the name of the i-th player


	M = size(W,1);       % number of players
	N = size(G,1);       % number of games in 2011 season 

	pv = 0.5;            % prior skill variance (prior mean is always 0)
	blocks = blockify(G,blockSize);
	numBlocks = numel(blocks);
	
	% struct to store the auxiliary variables. 
	% see initAux and updateAux for details
	aux = initAux(W,M,pv); 

	%% Initializing the messages from the game nodes to the skill nodes
	mgs = Message(zeros(N,2), zeros(N,2)); 
	
	for i=1:numBlocks	
		aux = updateAux(aux,blocks{i},i,blockSize);

		for iter=1:3
			fprintf('.');

			%% Message from skill nodes to game nodes
			msg = msgSkillToGame(mgs,aux);
				
			%% Message from game nodes to performance nodes
			mgp = msgGameToPerformance(msg,aux);
			
			%% Message from performance nodes to game nodes
			mpg = msgPerformanceToGame(mgp,aux);
			
			%% Message from game nodes to skill nodes
			mini_mgs = msgGameToSkill(mpg,msg,aux);
 
			mgs.P(aux.blockBegin:aux.blockEnd,:) = mini_mgs.P;
			mgs.h(aux.blockBegin:aux.blockEnd,:) = mini_mgs.h;
		end
	end

	aux.G = G;
	ratings = getRatings(mgs,aux);
end

function ratings = getRatings(mgs,aux)
	for p=1:aux.M
		Ps(p) = 1/aux.pv + sum(mgs.P(aux.G==p)); 
		hs(p) = sum(mgs.h(aux.G==p));
	end
	ratings = hs./Ps;
end

function	msg = msgSkillToGame(mgs,aux) 
	%% INSERT CODE HERE %%
	% (1) compute skill node beliefs 
	% (2) compute skill to game messages
	
	msg = Message(Psg,hsg);
end

function mgp = msgGameToPerformance(msg,aux)
	%% INSERT CODE HERE %%
	% (3) compute game to performance messages
	% Remember that player 1 always wins the way we store data
	
	mgp = Message(Pgp,hgp);
end

function mpg = msgPerformanceToGame(mgp,aux)	
	%% Useful functions 
	psi = inline('normpdf(x)./normcdf(x)');
	lambda = inline('(normpdf(x)./normcdf(x)).*( (normpdf(x)./normcdf(x)) + x)');

	%% INSERT CODE HERE %%
	% (4) project as in line 1 of KF Algorithm 11.5 (pg 441)
	% (5) compute performance to game messages as in line 4 
	%		of the same algorithm

	mpg = Message(Ppg,hpg);
end

function mgs = msgGameToSkill(mpg,msg,aux)
	%% INSERT CODE HERE %%
	% (6) compute game to skills messages
  
	mgs = Message(Pgs,hgs);
end

function aux = initAux(W,M,pv)
	aux = struct();
	aux.W = W;
	aux.M = M;
	aux.pv = pv;
end

function aux = updateAux(aux,block,i,blockSize)
	aux.G = block;
	aux.N = size(aux.G,1);
	aux.blockBegin = (i-1)*blockSize + 1;
	aux.blockEnd = aux.blockBegin + aux.N - 1;
	aux.players = unique(aux.G(:));
end


function blocks = blockify(X,blockSize)
	blocks = {};
	[numSamples numDimensions] = size(X);
	numBlocks = ceil(numSamples/blockSize);
	for i=1:numBlocks
		startPos = (i-1)*blockSize+1;
		endPos = min(numSamples,i*blockSize);
		blocks{i} = X(startPos:endPos,:);
	end
end


